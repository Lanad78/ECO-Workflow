# ECO Workflow Portal

Internal web app for ECO Consult: request workflows (logistics, agreements, invoicing, payments, due diligence, quality), plus the Projects, Proposals, Contacts, CVs and Staff databases — backed by Supabase.

Owner: Lana Daoud. **Every amendment goes through Lana** — code changes, database changes and access changes alike.

## Architecture

- `index.html` — the whole app (single file, no build step). Hosted as a static page.
- Supabase project `eco-workflow-portal` (org: ECO Work Flow Org, region eu-central-1, ref `ruiayxjartgdknonopiv`):
  - Postgres with row-level security (RLS) enforcing who sees and changes what, server-side.
  - Auth via email magic links (staff sign in with their `@ecoconsult.jo` work email).
  - `supabase/migrations/` holds the SQL applied to the database, for the record.

### Data model

| Table | Purpose |
|---|---|
| `people` | Staff directory: name, email, title, extension, mobile, department, `manager_id` (reporting line), `role` (`staff` / `ops` / `admin`), `active` |
| `requests` + `request_events` | All workflow requests with full audit trail |
| `handlers` | Which person processes each request type |
| `register` | Approved Third-Party Register (due diligence status, 12-month expiry) |
| `projects`, `proposals`, `contacts`, `cvs` | The databases; project codes `ECO-YYYY-NNN` and proposal refs `PRO-YYYY-NNN` are issued atomically by `next_ref()` |

### Access rules (enforced by RLS, not by the page)

- Only emails present in `people` (active) can read anything; anyone else who signs in sees "No access".
- Employees submit their own requests; a request is visible to everyone except confidential ones (submitter, their manager, ops only).
- Managers can act only on `pending_manager` requests of their own reports.
- `ops`/`admin` roles process the queue and manage Settings (handlers, register, staff).
- Projects/proposals/contacts/CVs: all staff read and add; edits by ops, the PM/lead or the creator; deletes ops-only.

## Workflow

Employee submits → line manager approves (direct-to-handler forms skip this: agreement requests, client invoice requests, non-conformity/quality reports) → Finance & Operations review/approve/complete in the Team queue. Payments and consultancy agreements are blocked without a valid Approved Third-Party Register entry, except by documented Management exception. A due-diligence nomination creates a pending register entry; approving it stamps a 12-month approval.

## One-time setup (Supabase dashboard)

1. **Auth → URL Configuration**: set Site URL to the deployed page URL (e.g. `https://<org>.github.io/eco-portal/`) and add it to Redirect URLs.
2. **Auth → Providers → Email**: keep Email enabled; magic link / OTP is used (no passwords). Optionally disable new sign-ups from unknown domains — not strictly needed, since RLS gives unknown emails no data.
3. Optional later: add Azure (Microsoft 365) SSO as a provider for one-click sign-in.

## Deploy (GitHub Pages)

1. Create a GitHub repository (e.g. `eco-portal`) under Lana's account; push these files.
2. Settings → Pages → Deploy from branch → `main` / root.
3. Put the resulting URL into Supabase Auth URL configuration (step above).
4. Custom domain (e.g. `portal.ecoconsult.jo`): add it in GitHub Pages settings and point a CNAME at `<org>.github.io`.

The `index.html` config block contains the Supabase URL and the **publishable** key — safe to commit; all authority lives in RLS.

## Changing things

- Content/UI: edit `index.html`, commit, push — Pages redeploys automatically.
- Database: apply a new SQL migration in Supabase (keep a copy in `supabase/migrations/`).
- Staff, handlers, register: no code needed — Settings tab in the app (ops/admin).

## Not yet included

- Email alerts on submission/approval (portal is fully functional without them; add later via a Supabase Edge Function with an email provider, or Microsoft Graph).
- CV file uploads (the CVs table links to files on the ECO server/SharePoint; Supabase Storage can host them later).
